# SemEval-2026 Task 13 Subtask A - Advanced Machine Learning Course
## Linear + NB-SVM + Handcrafted Tree Ensemble

## 1. Overview

This notebook builds a source-code classification pipeline for **SemEval-2026 Task 13 - Subtask A**, where the goal is to predict whether a code snippet is **Human-written (0)** or **AI-generated (1)**.

The main idea behind version `v6` is to combine three complementary modeling branches:

1. **Sparse linear baseline** over a large feature space composed of:
   - handcrafted structural features
   - word/token TF-IDF
   - char TF-IDF

2. **NB-SVM-style linear branch**:
   - uses the same sparse text representation
   - reweights TF-IDF features with a **log-count ratio** to emphasize class-discriminative tokens

3. **Tree-based branch** over **handcrafted features**:
   - focuses on non-linear interactions among coding style, formatting, and structural signals

This design aims to combine:
- **token-level signal** from TF-IDF
- **style-level / structure-level signal** from handcrafted features
- **model diversity across branches** for a more stable ensemble

---

## 2. Data Used

The notebook automatically detects the correct Kaggle data directory and reads the following files:

- `train.parquet`
- `validation.parquet`
- `test.parquet`
- `test_sample.parquet`

Observed split sizes in the notebook:

- `train`: **500,000** samples
- `validation`: **100,000** samples
- `test`: **500,000** samples
- `test_sample`: **1,000** samples

Observed class priors:

- `train` P(AI) = **0.523**
- `validation` P(AI) = **0.523**
- `test_sample` P(AI) = **0.223**

A key observation is that `test_sample` has a **substantially different class prior** from `train/validation`, so the notebook adds a **prior correction** step when calibrating probabilities and selecting the final threshold.

---

## 3. Pipeline Architecture

The pipeline consists of 10 main stages:

### Step 1 — Load and inspect the data
- Automatically detect `DATA_DIR`
- Read all required splits
- Fill missing values in the `code` column
- Check dataset sizes and label distributions

### Step 2 — Extract handcrafted features
The notebook builds **76 handcrafted features** to describe code style and structure, including:

- code length, line count, empty-line ratio
- line-length statistics
- token count, unique token count, unique identifier count
- naming-style statistics:
  - `snake_case`
  - `camelCase`
  - `UPPER_CASE`
- ratios of letters, digits, whitespace, and punctuation
- comment / inline comment / block comment / docstring signals
- indentation statistics
- repeated-line patterns
- operator counts and operator density
- string literal counts
- language / syntax keyword counts:
  - `if`, `else`, `for`, `while`
  - `return`, `import`, `class`, `def`
  - `try`, `except`, `lambda`, `async`, `await`
- language cues:
  - `c_like_score`
  - `python_score`
  - `js_score`
  - `java_score`
  - `sql_score`

### Step 3 — Represent code with TF-IDF
The pipeline uses two different views of the code:

#### 3.1 Word / token TF-IDF
- custom tokenizer for source code
- `max_features = 20000`

#### 3.2 Char TF-IDF
- `analyzer='char_wb'`
- `ngram_range=(2, 4)`
- `max_features = 12000`

Total text feature dimensionality:
- **32,000**

### Step 4 — Build branch-specific inputs
- **Linear branches** use:
  - scaled handcrafted features
  - sparse TF-IDF features
- **Tree branch** uses only:
  - raw handcrafted dense features

### Step 5 — Sparse linear baseline
Train `SGDClassifier(loss='log_loss')` on:
- scaled structural features
- word TF-IDF
- char TF-IDF

### Step 6 — NB-SVM branch
- Compute the **log-count ratio** between positive and negative classes on text features
- Reweight the sparse text matrix with that ratio vector
- Train `SGDClassifier(loss='log_loss')` on the transformed representation

### Step 7 — Tree branch
The notebook prefers:
- **LightGBM**, if available

If LightGBM is not available, it falls back to:
- **HistGradientBoostingClassifier**

This branch is trained only on the **76 handcrafted features**, allowing it to capture non-linear interactions that linear models may miss.

### Step 8 — Compare branches and test blends
The notebook evaluates multiple weight combinations across the 3 branches:

- `base`
- `nbsvm`
- `tree`

For each candidate blend, it:
- computes blended probabilities
- tests two strategies:
  1. **direct thresholding**
  2. **prior-corrected thresholding**
- tunes the threshold to maximize **macro F1**

Model selection criteria:
1. prioritize **macro F1 on `test_sample`**
2. if several candidates are very close, use **validation performance** as a tie-breaker to choose the more stable configuration

### Step 9 — Refit on train + validation
After selecting the best configuration, the notebook refits only the branches with non-zero weights on:
- `train + validation`

### Step 10 — Generate the submission file
- Predict on `test`
- Write `submission.csv` with the required format:
  - `ID`
  - `label`

---

## 4. Best Configuration Found in the Notebook

The final selected configuration is:

- **Blend weights**
  - base = **0.40**
  - nbsvm = **0.30**
  - tree = **0.30**

- **Inference strategy**
  - `prior_corrected`

- **Decision threshold**
  - **0.945**

Results on `test_sample`:

- `direct_f1` ≈ **0.4661**
- `prior-corrected macro F1` ≈ **0.5698**

This shows that **prior correction** is very important when the label distribution of the evaluation set differs from the training distribution.

Final prediction distribution on `test`:

- Human (0): **316,394**
- AI (1): **183,606**

---

## 5. Strengths of the Approach

- Combines both **lexical features** and **structural/style features**
- Uses an ensemble of linear and tree-based models for stronger diversity
- Explicitly handles **distribution shift / target prior shift**
- Refits on `train + validation` to use more labeled data before final inference on `test`
- Includes plots that are useful for reporting and analysis

---

## 6. Environment Requirements

Main libraries:

```bash
numpy
pandas
scipy
scikit-learn
joblib
matplotlib
pyarrow
lightgbm   # optional but recommended
```

If you want to submit directly from the Kaggle CLI:

```bash
kaggle
```

---

## 7. How to Run

### On Kaggle Notebook
1. Attach the competition dataset to the notebook.
2. Open `pipeline-v6.ipynb`.
3. Run all cells.
4. The notebook will automatically:
   - detect the data path
   - train the models
   - select the best blend
   - refit on `train + validation`
   - generate `submission.csv`

### Expected input files
The data directory should contain:

```bash
train.parquet
validation.parquet
test.parquet
test_sample.parquet
sample_submission.csv
```

---

## 8. Output

Final output file:

```bash
submission.csv
```

Format:

```csv
ID,label
0,0
1,1
2,0
...
```

---

## 9. Possible Improvements

- search a finer ensemble weight space instead of using a 0.1 step size
- apply branch-wise calibration before blending
- extend handcrafted features with AST-level or parser-level features
- try pseudo-labeling or self-training if the competition rules allow it
- replace threshold tuning with direct optimization on a more suitable validation split and metric setup

---

## 10. Main Project Files

- `pipeline-v6.ipynb`: training, evaluation, ensemble selection, and submission generation notebook
- `submission.csv`: final prediction file produced after running the notebook

---

## 11. Summary

This project uses a **multi-branch ensemble** for Human-vs-AI code classification, where:
- the linear branch extracts strong token- and character-level TF-IDF signals
- the NB-SVM branch improves text feature discrimination
- the tree branch models non-linear interactions in structural code features
- prior correction helps adapt to the class-prior mismatch between training and evaluation data
